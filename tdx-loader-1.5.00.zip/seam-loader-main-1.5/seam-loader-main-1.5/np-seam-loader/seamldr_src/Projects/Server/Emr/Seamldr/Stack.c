//**********************************************************************;
//*                                                                    *;
//* Intel Proprietary                                                  *;
//*                                                                    *;
//* Copyright 2021 Intel Corporation All Rights Reserved.              *;
//*                                                                    *;
//* Your use of this software is governed by the TDX Source Code       *;
//* LIMITED USE LICENSE.                                               *;
//*                                                                    *;
//* The Materials are provided "as is," without any express or         *;
//* implied warranty of any kind including warranties of               *;
//* merchantability, non-infringement, title, or fitness for a         *;
//* particular purpose.                                                *;
//*                                                                    *;
//**********************************************************************;

#include <common.h>
#include <text_alignment_padding.h>

#pragma optimize( "", off )

#pragma data_seg("SDATA32")
#pragma bss_seg("SDATA32")
#pragma const_seg("SDATA32")

UINT8 stackStart[STACK_SIZE + text_alignment_padding]; // Create stack space
