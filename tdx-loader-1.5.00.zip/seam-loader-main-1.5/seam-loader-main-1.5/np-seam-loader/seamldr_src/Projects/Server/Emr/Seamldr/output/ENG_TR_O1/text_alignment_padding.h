#define text_alignment_padding 0
