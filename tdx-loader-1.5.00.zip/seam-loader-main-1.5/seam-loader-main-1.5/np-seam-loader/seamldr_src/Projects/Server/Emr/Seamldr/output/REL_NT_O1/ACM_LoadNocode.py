//Couldn't locate .pdb file in .rdata section, no ITPII command generated.
