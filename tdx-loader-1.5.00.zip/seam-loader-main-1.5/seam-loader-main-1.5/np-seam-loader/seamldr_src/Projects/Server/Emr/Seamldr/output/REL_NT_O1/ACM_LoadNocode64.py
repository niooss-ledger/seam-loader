//Couldn't locate .pdb file in .rdata section, no ITP command generated.
